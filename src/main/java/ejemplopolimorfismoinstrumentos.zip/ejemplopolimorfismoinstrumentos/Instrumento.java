package ejemplopolimorfismoinstrumentos;

/**
 *
 * Clase Instrumento
 */
public class Instrumento {

    private String familia;
    private double afinacionLa;
//    private Persona instrumentista;

    public void afinar(double afinacion) {
        this.afinacionLa = afinacion;
        System.out.println("Instrumento afinado a " + afinacion + "Hz");
    }

    /**
     * Método que escribe como se toca una nota que recibe por parámetro
     *
     * @param nota Nota que va a ser tocada
     */
    public void tocarNota(String nota) {
        System.out.printf("Tocar nota %s.\n", nota);
//        System.out.printf("Tocar nota " + nota + ".\n");
//        System.out.print("Tocar nota " + nota + "\n");
//        System.out.println("Tocar nota " + nota);
    }

}
